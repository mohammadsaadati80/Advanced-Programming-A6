#ifndef __FRED_BOT_HPP__
#define __FRED_BOT_HPP__ 

#include "channel.hpp"
#include "robot.hpp"

class FredBot : public Robot
{
public:
	explicit FredBot(Channel& channel);
	~FredBot() override;

	void onMessageReceived(Message message) override;
	
private:
	void greet();

	Channel& channel;
};

#endif