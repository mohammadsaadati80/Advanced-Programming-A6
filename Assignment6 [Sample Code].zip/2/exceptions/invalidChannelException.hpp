#ifndef __INVALID_CHANNEL_EXCEPTION_HPP__
#define __INVALID_CHANNEL_EXCEPTION_HPP__ 

#include <stdexcept>

class InvalidChannelException : std::exception
{
public:
	const char* what() const noexcept override;
};

#endif