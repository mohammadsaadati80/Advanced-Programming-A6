#include "invalidCommandException.hpp"

const char* InvalidCommandException::what() const noexcept {
	return "Invalid Command";
}