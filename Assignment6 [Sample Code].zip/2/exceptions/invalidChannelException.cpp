#include "invalidChannelException.hpp"

const char* InvalidChannelException::what() const noexcept {
	return "Channel does not exist";
}