#ifndef __CIRCULAR_DEPENDENCY_EXCEPTION_HPP__
#define __CIRCULAR_DEPENDENCY_EXCEPTION_HPP__ 

#include <stdexcept>

class CircularDependencyException : std::exception
{
public:
	const char* what() const noexcept override;
};

#endif