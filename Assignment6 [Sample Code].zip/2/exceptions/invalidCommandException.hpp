#ifndef __INVALID_COMMAND_EXCEPTION_HPP__
#define __INVALID_COMMAND_EXCEPTION_HPP__ 

#include <stdexcept>

class InvalidCommandException : std::exception
{
public:
	const char* what() const noexcept override;
};

#endif