#include "circularDependencyException.hpp"

const char* CircularDependencyException::what() const noexcept {
	return "Channel already exists";
}