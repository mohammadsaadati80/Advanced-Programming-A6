#include "duplicateChannelException.hpp"

const char* DuplicateChannelException::what() const noexcept {
	return "Channel already exists";
}