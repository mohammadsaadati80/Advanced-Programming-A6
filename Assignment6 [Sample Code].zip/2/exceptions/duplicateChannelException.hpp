#ifndef __DUPLICATE_CHANNEL_EXCEPTION_HPP__
#define __DUPLICATE_CHANNEL_EXCEPTION_HPP__ 

#include <stdexcept>

class DuplicateChannelException : std::exception
{
public:
	const char* what() const noexcept override;
};

#endif