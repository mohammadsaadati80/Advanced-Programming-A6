#include "librarianBot.hpp"

LibrarianBot::LibrarianBot(Channel& channel) : 
libraryChannel(channel) {
	
}

LibrarianBot::~LibrarianBot() = default;

void LibrarianBot::onMessageReceived(Message message) {
	counter++;
	if(counter == 5) {
		counter = 0;
		hush();
	}
}

void LibrarianBot::hush() {
	libraryChannel.broadcast("Quiet!");
}