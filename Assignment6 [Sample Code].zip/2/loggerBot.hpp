#ifndef __LOGGER_BOT_HPP__
#define __LOGGER_BOT_HPP__ 

#include "channel.hpp"
#include "robot.hpp"
#include <fstream>

class LoggerBot : public Robot
{
public:
	explicit LoggerBot(std::string logFilename);
	~LoggerBot() override;

	void onMessageReceived(Message message) override;
	
private:
	void log(Message message);

	std::ofstream logFile;
};

#endif