#ifndef __DISPATCHER_HPP__
#define __DISPATCHER_HPP__

#include "database.hpp"
#include <memory>
#include <vector>

class Dispatcher
{
public:
	Dispatcher(const Database& database);
	
	void subscribe(Message message, std::string channelName);
	void send(Message message, std::string channelName);

private:
	const Database& database;
};

#endif