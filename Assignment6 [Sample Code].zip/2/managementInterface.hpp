#ifndef __MANAGEMENT_INTERFACE_HPP__
#define __MANAGEMENT_INTERFACE_HPP__

#include "database.hpp"

class ManagementInterface
{
public:
	explicit ManagementInterface(Database& database);
	
	void parseCommand(std::string command);

private:
	void addBot(std::vector<std::string> args);
	void addChannel(std::string name);
	void tell(std::vector<std::string> args);
	
	void addEchoBot(std::vector<std::string> args);
	void addLoggerBot(std::vector<std::string> args);
	void addFredBot(std::vector<std::string> args);
	void addLibrarianBot(std::vector<std::string> args);

	static std::vector<std::string> split(std::string command, std::size_t wordLimit);

	Database& database;
};

#endif