#include "fredBot.hpp"

FredBot::FredBot(Channel& channel) : 
channel(channel) {

}

FredBot::~FredBot() = default;

void FredBot::onMessageReceived(Message message) {
	if(message == "Hi") {
		greet();
	}
}

void FredBot::greet() {
	channel.broadcast("Hello");
}