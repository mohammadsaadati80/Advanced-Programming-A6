#ifndef __ECHO_BOT_HPP__
#define __ECHO_BOT_HPP__ 

#include "channel.hpp"
#include "robot.hpp"

class EchoBot : public Robot
{
public:
	explicit EchoBot(Channel& outputChannel);
	~EchoBot() override;

	void onMessageReceived(Message message) override;
	
private:
	void echo(Message message);

	Channel& outputChannel;
};

#endif