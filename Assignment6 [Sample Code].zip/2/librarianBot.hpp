#ifndef __LIBRARIAN_BOT_HPP__
#define __LIBRARIAN_BOT_HPP__ 

#include "channel.hpp"
#include "robot.hpp"

class LibrarianBot : public Robot
{
public:
	explicit LibrarianBot(Channel& channel);
	~LibrarianBot() override;

	void onMessageReceived(Message message) override;
	
private:
	void hush();

	Channel& libraryChannel;
	unsigned int counter = 0;
};

#endif