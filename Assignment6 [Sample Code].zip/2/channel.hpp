#ifndef __CHANNEL_HPP__
#define __CHANNEL_HPP__

#include <vector>
#include <memory>
#include "robot.hpp"

class Channel
{
public:
	explicit Channel(std::string name);

	void broadcast(Message message);

	void subscribe(Robot& subscriber);

	bool compareName(const std::string& name) const;
	bool compareName(const Channel& other) const;

private:
	void notifyAll(Message message) const;
	void notify(Robot& bot, Message message) const;

	std::string name;
	std::vector<std::reference_wrapper<Robot>> subscribers;
};

#endif