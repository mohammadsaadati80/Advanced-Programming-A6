#ifndef __MESSAGING_SYSTEM_HPP__
#define __MESSAGING_SYSTEM_HPP__ value

class MessagingSystem
{
public:
	MessagingSystem();
	~MessagingSystem();
	
	void createRobot();
};

#endif