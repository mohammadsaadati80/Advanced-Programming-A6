#include "managementInterface.hpp"
#include "echoBot.hpp"
#include "librarianBot.hpp"
#include "fredBot.hpp"
#include "loggerBot.hpp"
#include "exceptions/circularDependencyException.hpp"
#include "exceptions/invalidCommandException.hpp"
#include <sstream>
#include <iostream>

ManagementInterface::ManagementInterface(Database& database) :
database(database) {
}

void ManagementInterface::parseCommand(std::string command) {
	auto commandWords = split(std::move(command), 2);
	if(commandWords[0] == "add_channel") {
		addChannel(std::move(commandWords[1]));
	}
	else if(commandWords[0] == "add_bot") {
		addBot(split(commandWords[1], 2));
	}
	else if(commandWords[0] == "tell") {
		tell(split(commandWords[1], 2));
	}
	else {
		throw InvalidCommandException();
	}
}

void ManagementInterface::addBot(std::vector<std::string> args) {
	if(args[0] == "echo") {
		addEchoBot(split(args[1], 2));
	}
	else if(args[0] == "logger") {
		addLoggerBot(split(args[1], 1));
	}
	else if(args[0] == "fred") {
		addFredBot(split(args[1], 1));
	}
	else if(args[0] == "librarian") {
		addLibrarianBot(split(args[1], 1));
	}
	else {
		throw InvalidCommandException();
	}
}

void ManagementInterface::addChannel(std::string name) {
	database.addChannel(new Channel(name));
}

void ManagementInterface::tell(std::vector<std::string> args) {
	database.getChannel(args[0]).broadcast(args[1]);
}

void ManagementInterface::addEchoBot(std::vector<std::string> args) {
	if(args[0] == args[1]) {
		throw CircularDependencyException();
	}
	auto& src = database.getChannel(args[0]);
	auto& dest = database.getChannel(args[1]);
	auto bot = new EchoBot(dest);
	database.addBot(bot);
	src.subscribe(*bot);
}

void ManagementInterface::addLoggerBot(std::vector<std::string> args) {
	auto bot = new LoggerBot(args[0]);
	database.addBot(bot);
	for(auto channel : database.getAllChannels()) {
		channel->subscribe(*bot);
	}
}

void ManagementInterface::addFredBot(std::vector<std::string> args) {
	auto& channel = database.getChannel(args[0]);
	auto bot = new FredBot(channel);
	database.addBot(bot);
	channel.subscribe(*bot);
}

void ManagementInterface::addLibrarianBot(std::vector<std::string> args) {
	auto& channel = database.getChannel(args[0]);
	auto bot = new LibrarianBot(channel);
	database.addBot(bot);
	channel.subscribe(*bot);
}

std::vector<std::string> ManagementInterface::split(std::string command, std::size_t wordLimit) {
	if(command[command.size()-1] == '\n') {
		command = command.substr(0, command.size() - 1);
	}
    std::vector<std::string> splitCommand;
	std::size_t current, previous = 0;
    current = command.find(' ');
    while (current != std::string::npos && wordLimit > 1) {
        splitCommand.push_back(command.substr(previous, current - previous));
        previous = current + 1;
        current = command.find(' ', previous);
        wordLimit--;
    }
    splitCommand.push_back(command.substr(previous, std::string::npos - previous));
    return splitCommand;
}
