#include "managementInterface.hpp"
#include <iostream>
#include <stdexcept>

int main() {
	Database database;
	ManagementInterface managementInterface(database);
	std::string line;
	while(std::getline(std::cin, line)) {
		try {
			managementInterface.parseCommand(line);
		}
		catch(std::exception& e) {
			std::cout << e.what() << std::endl;
		}
	}
	return 0;
}