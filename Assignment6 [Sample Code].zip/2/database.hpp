#ifndef __DATABASE_HPP__
#define __DATABASE_HPP__

#include "robot.hpp"
#include "channel.hpp"
#include <vector>

class Database
{
public:
	Database() = default;
	~Database();

	void addBot(Robot* bot);
	void addChannel(Channel* channel);

	const std::vector<Channel*>& getAllChannels() const;
	Channel& getChannel(std::string name) const;

private:
	std::vector<Robot*> bots;
	std::vector<Channel*> channels;
};

#endif