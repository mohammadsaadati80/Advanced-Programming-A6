#include "loggerBot.hpp"

LoggerBot::LoggerBot(std::string logFilename) {
	logFile.open(logFilename);
}

void LoggerBot::onMessageReceived(Message message) {
	log(std::move(message));
}

void LoggerBot::log(Message message) {
	logFile << message << std::endl;
}

LoggerBot::~LoggerBot() {
	logFile.close();
}