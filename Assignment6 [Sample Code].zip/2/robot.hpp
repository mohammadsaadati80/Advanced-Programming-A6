#ifndef __ROBOT_HPP__
#define __ROBOT_HPP__

#include <string>

using Message = std::string;

class Robot
{
public:
	virtual ~Robot() = default;

	virtual void onMessageReceived(Message message) = 0;
	
};

#endif