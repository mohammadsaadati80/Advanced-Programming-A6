#include "database.hpp"
#include "exceptions/duplicateChannelException.hpp"
#include "exceptions/invalidChannelException.hpp"

Database::~Database() {
	for(auto channel : channels) {
		delete channel;
	}
	for(auto bot : bots) {
		delete bot;
	}
}

void Database::addBot(Robot* bot) {
	bots.push_back(bot);
}

void Database::addChannel(Channel* channel) {
	for(auto registeredChannel : channels) {
		if(registeredChannel->compareName(*channel)) {
			delete channel;
			throw DuplicateChannelException();
		}
	}
	channels.push_back(channel);
}

Channel& Database::getChannel(std::string name) const {
	for(auto channel : channels) {
		if(channel->compareName(name)) {
			return *channel;
		}
	}
	throw InvalidChannelException();
}

const std::vector<Channel*>& Database::getAllChannels() const {
	return channels;
}
