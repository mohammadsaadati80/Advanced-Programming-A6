#include "channel.hpp"
#include <algorithm>

Channel::Channel(std::string name) : name(std::move(name)) {
}

void Channel::broadcast(Message message) {
	notifyAll(std::move(message));
}

void Channel::subscribe(Robot& subscriber) {
	subscribers.push_back(subscriber);
}

bool Channel::compareName(const std::string& name) const {
	return name == this->name;
}

bool Channel::compareName(const Channel& other) const {
	return other.name == this->name;
}

void Channel::notifyAll(Message message) const {
	for(auto subscriber : subscribers) {
		notify(subscriber, message);
	}
}

void Channel::notify(Robot& bot, Message message) const {
	bot.onMessageReceived(std::move(message));
}
