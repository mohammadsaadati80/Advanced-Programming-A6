#include "echoBot.hpp"
#include <iostream>

EchoBot::EchoBot(Channel& outputChannel) : 
outputChannel(outputChannel) {

}

EchoBot::~EchoBot() = default;

void EchoBot::onMessageReceived(Message message) {
	echo(std::move(message));
}

void EchoBot::echo(Message message) {
	outputChannel.broadcast(std::move(message));
}