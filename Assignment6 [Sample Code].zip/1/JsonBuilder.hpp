#ifndef __JSON_BUILDER_H__
#define __JSON_BUILDER_H__

#include <string>
#include <vector>
#include <iostream>
#include "Object.hpp"
#include "Array.hpp"
#include "String.hpp"
#include "Integer.hpp"
#include "Exception.hpp"

#define MOTHER_OBJECT_ID 0
#define ARRAY_TYPE "array"
#define OBJECT_TYPE "object"

class JsonBuilder
{
    public:
        JsonBuilder();
        ~JsonBuilder();
        void addStringToObject(int parentId, std::string key, std::string value);
        void addIntegerToObject(int parentId, std::string key, int value);
        int addContainerToObject(int parentId, std::string key, std::string type);
        void addStringToArray(int parentId, std::string value);
        void addIntegerToArray(int parentId, int value);
        int addContainerToArray(int parentId, std::string type);
        void print(int id);
        
        Item* findItem(int id);
        int getNewId() {return nextId++;}
    private:
        Item* motherObject;
        int nextId;

};

#endif 