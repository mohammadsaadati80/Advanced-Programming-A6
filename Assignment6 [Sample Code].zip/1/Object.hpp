#ifndef __OBJECT_H__
#define __OBJECT_H__

#include <vector>
#include <string>

#include "Item.hpp"
#include "String.hpp"
#include "Integer.hpp"

struct Data
{
    std::string key;
    Item* item;
};


class Object: public Item
{
public:
    Object(int _id): id(_id) {}
    ~Object();
    Item* findId(int id);
    void print(int indentationNum);
    void addData(Data* newData);
    bool isDuplicateKey(std::string key);

private:
    std::vector<Data*> datas;
    int id;
};


#endif