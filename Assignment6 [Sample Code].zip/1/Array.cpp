#include "Array.hpp"

Array::~Array() {
	for(auto element : arrayItems) {
		delete element;
	}
}

Item* Array::findId(int _id)
{
    if(id == _id)
        return this;
    for(int i = 0; i < arrayItems.size(); i++)
    {
        Item* foundItem = arrayItems[i]->findId(_id);
        if(foundItem != NULL)
            return foundItem;
    }   
    return NULL;
}

void Array::print(int indentationNum)
{
    if(indentationNum == 0)
        throw(InvalidID());

    std::cout<<"[";
    for(int i = 0; i < arrayItems.size(); i++)
    {
        std::cout<<"\n";
        printIndentaition(indentationNum + 1);
        arrayItems[i]->print(indentationNum + 1);
        if(i != arrayItems.size() - 1)
            std::cout<<",";
        else  
            std::cout<<"\n";
    }
    if(arrayItems.size() != 0)
        printIndentaition(indentationNum);
    std::cout<<"]";
}

void Array::addElement(Item* newItem)
{
    arrayItems.push_back(newItem);
}