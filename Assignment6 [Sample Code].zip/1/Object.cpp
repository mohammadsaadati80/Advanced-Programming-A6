#include "Object.hpp"

Object::~Object() {
	for(auto data : datas) {
		delete data;
	}
}

Item* Object::findId(int _id)
{
    if(id == _id)
        return this;
    for(int i = 0; i < datas.size(); i++)
    {
        Item* foundItem = datas[i]->item->findId(_id);
        if(foundItem != NULL)
            return foundItem;
    }
    return NULL;
}

void Object::print(int indentationNum)
{
    std::cout<<"{";
    for(int i = 0; i < datas.size(); i++)
    {
        std::cout<<"\n";
        printIndentaition(indentationNum + 1);
        std::cout<<"\""<<datas[i]->key<<"\""<<": ";
        datas[i]->item->print(indentationNum + 1);
        if(i != datas.size() - 1)
            std::cout<<",";
        else 
            std::cout<<"\n";
    }
    if(datas.size() != 0)
        printIndentaition(indentationNum);
    std::cout<<"}";
}

void Object::addData(Data* newData)
{
    if(isDuplicateKey(newData->key))
        throw(DuplicateKey());
    datas.push_back(newData);
}

bool Object::isDuplicateKey(std::string key)
{
    for(int i = 0; i < datas.size(); i++)
    {
        if(datas[i]->key == key)
            return true;
    }
    return false;
}
