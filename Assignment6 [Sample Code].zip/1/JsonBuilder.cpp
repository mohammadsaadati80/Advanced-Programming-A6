#include "JsonBuilder.hpp"

JsonBuilder::JsonBuilder()
{
    motherObject = new Object(MOTHER_OBJECT_ID);
    nextId = 1;
}

JsonBuilder::~JsonBuilder() {
	delete motherObject;
}

Item* JsonBuilder::findItem(int id)
{
    return motherObject->findId(id);
}

void JsonBuilder::addStringToObject(int parentId, std::string key, std::string value)
{
    Item* object = findItem(parentId);
    if(object != NULL)
    {
        Data* newData = new Data();
        newData->key = key;
        newData->item = new String(value);
        object->addData(newData);
    }
    else
    {
        throw(InvalidID());
    }
    
}

void JsonBuilder::addIntegerToObject(int parentId, std::string key, int value)
{
    Item* object = findItem(parentId);
    if(object != NULL)
    {
        Data* newData = new Data();
        newData->key = key;
        newData->item = new Integer(value);
        object->addData(newData);
    }
    else
    {
        throw(InvalidID());
    }
    
}

int JsonBuilder::addContainerToObject(int parentId, std::string key, std::string type)
{
    Item* object = findItem(parentId);
    if(object != NULL)
    {
        int newId = getNewId();
        Data* newData = new Data();
        newData->key = key;
        if(type == ARRAY_TYPE)
            newData->item = new Array(newId);
        else if(type == OBJECT_TYPE)
            newData->item = new Object(newId);
        else 
            throw(UndefinedType());
        object->addData(newData);
        return newId;
    }
    else
    {
        throw(InvalidID());
    }
}

void JsonBuilder::addStringToArray(int parentId, std::string value)
{
    Item* array = findItem(parentId);
    if(array != NULL)
    {
        array->addElement(new String(value));
    }
    else
    {
        throw(InvalidID());
    }
}

void JsonBuilder::addIntegerToArray(int parentId, int value)
{
    Item* array = findItem(parentId);
    if(array != NULL)
    {
        array->addElement(new Integer(value));
    }
    else
    {
        throw(InvalidID());
    }
}

int JsonBuilder::addContainerToArray(int parentId, std::string type)
{
    Item* array = findItem(parentId);
    if(array != NULL)
    {
        int newId = getNewId();
        if(type == ARRAY_TYPE)
            array->addElement(new Array(newId));
        else if(type == OBJECT_TYPE)
            array->addElement(new Object(newId));
        else
            throw(UndefinedType());
        return newId;
    }
    else
    {
        throw(InvalidID());
    }
}

void JsonBuilder::print(int id)
{
    Item* object = findItem(id);
    if(object == NULL)
        throw(InvalidID());
    object->print(0);
    std::cout<<"\n";
}