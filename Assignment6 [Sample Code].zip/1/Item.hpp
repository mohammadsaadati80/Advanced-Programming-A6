#ifndef __ITEM_H__
#define __ITEM_H__

#include <iostream>
#include "Exception.hpp"

#define Tab "    "

struct Data;

class Item
{
public:
    virtual Item* findId(int id) = 0;
    virtual void print(int indentationNum) = 0;
    void printIndentaition(int indentationNum);

    virtual void addData(Data* newData) {throw(InvalidID());};
    virtual void addElement(Item* newItem) {throw(InvalidID());}

private:

protected:
};


#endif