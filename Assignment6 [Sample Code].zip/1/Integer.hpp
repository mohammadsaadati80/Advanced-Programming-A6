#ifndef __INTEGER_H__
#define __INTEGER_H__

#include "Item.hpp"

class Integer: public Item
{
public:
    Integer(int _value):  value(_value) {}
    void print(int indentationNum) {std::cout<<value;};
    Item* findId(int id) {return NULL;}

private:
    int value;

};


#endif