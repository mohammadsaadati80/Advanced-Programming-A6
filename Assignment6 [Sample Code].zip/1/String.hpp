#ifndef __STRING_H__
#define __STRING_H__

#include "Item.hpp"
#include <string>

class String: public Item
{
public:
    String(std::string _value): value(_value) {}
    void print(int indentationNum) {std::cout<<"\""<<value<<"\"";};
    Item* findId(int id) {return NULL;}
private:
    std::string value;
};


#endif