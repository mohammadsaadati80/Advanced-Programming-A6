#ifndef __EXCEPTION_H__
#define __EXCEPTION_H__

#include <exception>

using namespace std;

class InvalidID: public exception
{
    
    virtual const char* what() const noexcept
    {
        return "Invalid ID.\n";
    }
};

class DuplicateKey: public exception
{
    
    virtual const char* what() const noexcept
    {
        return "Duplicate key.\n";
    }
};

class UndefinedType: public exception
{
    
    virtual const char* what() const noexcept
    {
        return "Undefined type.\n";
    }
};

#endif

