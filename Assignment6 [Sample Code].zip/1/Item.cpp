#include "Item.hpp"

void Item::printIndentaition(int indentationNum)
{
    for(int i = 0; i < indentationNum; i++)
        std::cout<<Tab;
}