#ifndef __ARRAY_H__
#define __ARRAY_H__

#include <vector>
#include "Item.hpp"
#include "String.hpp"
#include "Integer.hpp"


class Array: public Item
{
    public:
    Array(int _id): id(_id) {}
    ~Array();
    void print(int indentationNum);
    Item* findId(int id);
    void addElement(Item* newItem);

    private:
    std::vector<Item*> arrayItems;
    int id;
    
};


#endif