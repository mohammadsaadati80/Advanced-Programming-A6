#include "World.hpp"
using namespace std;

int main()
{
	World world;
	world.check_command();
	return 0;
}
